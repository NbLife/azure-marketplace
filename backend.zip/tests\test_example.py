# backend/tests/test_example.py
def test_example():
    assert 1 + 1 == 2
