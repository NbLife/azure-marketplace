async function e(){let e=await fetch("http://127.0.0.1:8000/items"),t=await e.json(),n=document.getElementById("products");n.innerHTML="",t.forEach(e=>{let t=document.createElement("div");t.className="product",t.innerHTML=`<h3>${e.name}</h3><p>Cena: ${e.price} PLN</p>`,n.appendChild(t)})}document.addEventListener("DOMContentLoaded",e);
//# sourceMappingURL=index.f296d425.js.map
